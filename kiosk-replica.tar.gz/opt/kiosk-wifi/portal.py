
#!/usr/bin/env python3

import base64
import html
import ipaddress
import json
import logging
import os
import queue
import socket
import secrets
import subprocess
import threading
import time
import uuid

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs

WIFI = "wlan0"
AP = "kiosk-setup"
AP_SSID = socket.gethostname().split(".")[0]
AP_IP = "192.168.4.1"
PORTAL_HOST = "kiosk.lan"

ROOT = Path("/opt/kiosk-wifi")
OFFLINE = ROOT / "offline.html"
CACHE = ROOT / "networks.json"

WAIT_FOR_WIFI = 45

jobs = queue.Queue(maxsize=1)
tokens = {}
token_lock = threading.Lock()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)


def nm(*args, timeout=60):
    try:
        return subprocess.run(
            ["nmcli", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False
        )
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(
            args, 124, "", "Timeout"
        )


def current_connection():
    r = nm(
        "-g", "GENERAL.CONNECTION",
        "device", "show", WIFI,
        timeout=10
    )
    return r.stdout.strip() if r.returncode == 0 else ""


def wifi_online():
    if current_connection() in ("", "--", AP):
        return False

    state = nm(
        "-g", "GENERAL.STATE",
        "device", "show", WIFI,
        timeout=10
    )

    ip = nm(
        "-g", "IP4.ADDRESS",
        "device", "show", WIFI,
        timeout=10
    )

    return (
        state.returncode == 0
        and state.stdout.strip().startswith("100")
        and ip.returncode == 0
        and bool(ip.stdout.strip())
    )

def ethernet_online():
    try:
        result = subprocess.run(
            ["/usr/local/bin/kiosk-ethernet-online"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=7,
            check=False
        )

        return result.returncode == 0

    except (subprocess.TimeoutExpired, OSError):
        return False


def ap_active():
    return current_connection() == AP


def ap_password():
    result = nm(
        "--show-secrets",
        "-g", "802-11-wireless-security.psk",
        "connection", "show", "id", AP,
        timeout=10
    )

    if result.returncode != 0 or not result.stdout.strip():
        raise RuntimeError("Password hotspot non disponibile")

    return result.stdout.strip()


def ap_ssid():
    result = nm(
        "-g", "802-11-wireless.ssid",
        "connection", "show", "id", AP,
        timeout=10
    )

    if result.returncode != 0 or not result.stdout.strip():
        raise RuntimeError("SSID hotspot non disponibile")

    return result.stdout.strip()


def qr_escape(value):
    return "".join(
        "\\" + c if c in '\\;,:\"' else c
        for c in value
    )


def hotspot_qrcode():
    ssid = ap_ssid()
    password = ap_password()

    if (
        not ssid
        or not password
        or ssid in ("None", "--")
        or password in ("None", "--")
    ):
        logging.error("Credenziali hotspot non valide per QR")
        return '<p>QR code non disponibile</p>'

    def escape_wifi(value):
        return "".join(
            "\\" + c if c in '\\;,:\"' else c
            for c in value
        )

    payload = (
        f"WIFI:T:WPA;"
        f"S:{escape_wifi(ssid)};"
        f"P:{escape_wifi(password)};;"
    )

    result = subprocess.run(
        ["qrencode", "-t", "PNG", "-s", "8", "-o", "-"],
        input=payload.encode("utf-8"),
        capture_output=True,
        check=True
    )

    encoded = base64.b64encode(
        result.stdout
    ).decode("ascii")

    return (
        '<div class="qrcode">'
        f'<img src="data:image/png;base64,{encoded}" '
        'alt="Connessione Wi-Fi tramite QR code">'
        '</div>'
    )

def render_offline(message=""):
    password = html.escape(ap_password())
    ssid = html.escape(ap_ssid())
    qr_html = hotspot_qrcode()

    alert = ""
    if message:
        alert = (
            '<div class="alert">' +
            html.escape(message) +
            '</div>'
        )

    document = f"""<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="10">
<title>Configurazione Wi-Fi</title>
<style>
* {{ box-sizing:border-box }}
body {{
    margin:0; padding:30px;
    background:#101827; color:white;
    font-family:system-ui,sans-serif;
    min-height:100vh; display:flex;
    align-items:center; justify-content:center;
}}
main {{ width:100%; max-width:780px; text-align:center }}
h1 {{ font-size:clamp(28px,4vw,46px) }}
p {{ color:#cbd5e1; font-size:20px; line-height:1.6 }}
.card {{
    background:#24344b; border-radius:18px;
    padding:32px; margin:28px 0;
}}
.label {{
    color:#a8b9cf; font-size:15px;
    margin:15px 0 6px;
}}
.value {{
    font-size:clamp(22px,3vw,34px);
    font-weight:650; overflow-wrap:anywhere;
}}
.url {{
    background:white; color:#182230;
    padding:20px; border-radius:12px;
    font-size:clamp(23px,3vw,34px);
    font-weight:bold;
}}
.alert {{
    background:#6c2935; border:1px solid #f87171;
    padding:18px; border-radius:12px;
    font-size:20px;
}}
.qrcode {{
    margin: 24px auto;
    text-align: center;
}}
.qrcode img {{
    width: 240px;
    max-width: 100%;
    padding: 12px;
    background: white;
    border-radius: 12px;
}}
.qrcode p {{
    font-size: 17px;
    color: #cbd5e1;
}}
</style>
</head>
<body>
<main>
<h1>Configurazione Wi-Fi necessaria</h1>
{alert}
<p>1. Collega il tuo smartphone a questo hotspot:</p>
<div class="card">
  <div class="label">NOME RETE</div>
  <div class="value">{ssid}</div>
  <div class="label">PASSWORD</div>
  <div class="value">{password}</div>
</div>
{qr_html}
<p>2. Apri il browser del telefono:</p>
<div class="url">http://kiosk.lan</div>
<p>3. Seleziona una rete Wi-Fi, inserisci la password
e premi Connetti.</p>
<p>La dashboard si aprirà automaticamente dopo
una connessione riuscita.</p>
</main>
</body>
</html>
"""

    temp = ROOT / "offline.html.tmp"
    temp.write_text(document, encoding="utf-8")
    temp.chmod(0o644)
    os.replace(temp, OFFLINE)


def restart_kiosk():
    try:
        r = subprocess.run(
            [
                "systemctl",
                "--no-block",
                "try-restart",
                "kiosk.service"
            ],
            capture_output=True,
            text=True,
            timeout=10,
            check=False
        )

        if r.returncode != 0:
            logging.error(
                "Richiesta riavvio Kiosk fallita: %s",
                r.stderr.strip()
            )

    except subprocess.TimeoutExpired:
        logging.warning(
            "Timeout invio comando di riavvio Kiosk"
        )

    except Exception:
        logging.exception(
            "Errore durante richiesta riavvio Kiosk"
        )


def saved_networks():
    try:
        return json.loads(CACHE.read_text())
    except (FileNotFoundError, ValueError):
        return []


def scan_networks():
    logging.info("Scansione reti Wi-Fi")

    nm(
        "device", "wifi", "rescan",
        "ifname", WIFI,
        timeout=25
    )
    time.sleep(2)

    r = nm(
        "--escape", "no",
        "-g", "SSID",
        "device", "wifi", "list",
        "ifname", WIFI,
        "--rescan", "no",
        timeout=15
    )

    if r.returncode:
        logging.warning("Scansione non riuscita")
        return saved_networks()

    names = sorted({
        name.strip()
        for name in r.stdout.splitlines()
        if name.strip()
        and name.strip() != ap_ssid()
        and len(name.strip().encode("utf-8")) <= 32
    }, key=str.casefold)

    CACHE.write_text(json.dumps(names, ensure_ascii=False))
    logging.info("Reti rilevate: %d", len(names))
    return names


def start_ap():
    if ap_active():
        return True

    logging.info("Attivazione hotspot")

    r = nm(
        "--wait", "30",
        "connection", "up", "id", AP,
        "ifname", WIFI,
        timeout=40
    )

    if r.returncode:
        logging.error("Hotspot: %s", r.stderr.strip())

    return r.returncode == 0


def connect_new_wifi(ssid, password):
    uid = str(uuid.uuid4())
    name = "kiosk-client-" + uid[:8]

    logging.info("Creazione profilo Wi-Fi: %s", ssid)

    r = nm(
        "connection", "add",
        "type", "wifi",
        "ifname", WIFI,
        "con-name", name,
        "connection.uuid", uid,
        "connection.autoconnect", "no",
        "ssid", ssid,
        "wifi.mode", "infrastructure",
        "wifi-sec.key-mgmt", "wpa-psk",
        "wifi-sec.psk", password,
        "ipv4.method", "auto",
        "ipv4.may-fail", "no",
        "ipv4.dhcp-timeout", "45",
        "ipv6.method", "disabled",
        timeout=25
    )

    if r.returncode != 0:
        logging.error(
            "Creazione profilo fallita: %s",
            r.stderr.strip()
        )
        return False, "Impossibile creare il profilo Wi-Fi."

    # Spegne l'hotspot per liberare wlan0.
    if ap_active():
        logging.info("Disattivazione hotspot")

        stop = nm(
            "--wait", "20",
            "connection", "down", "id", AP,
            timeout=25
        )

        if stop.returncode != 0:
            logging.error(
                "Impossibile fermare hotspot: %s",
                stop.stderr.strip()
            )
            nm("connection", "delete", "uuid", uid)
            return False, "Impossibile disattivare l'hotspot."

    time.sleep(2)

    # Prova la connessione.
    logging.info("Tentativo connessione: %s", ssid)

    r = nm(
        "--wait", "65",
        "connection", "up", "uuid", uid,
        "ifname", WIFI,
        timeout=75
    )

    logging.info(
        "NMCLI: code=%s stdout=%r stderr=%r",
        r.returncode,
        r.stdout.strip(),
        r.stderr.strip()
    )

    # Verifica il profilo attivo e l'indirizzo IPv4.
    # Non elimina la rete al primo controllo fallito.
    success = False

    if r.returncode == 0:
        deadline = time.monotonic() + 20

        while time.monotonic() < deadline:
            active_uuid = nm(
                "-g", "GENERAL.CON-UUID",
                "device", "show", WIFI,
                timeout=10
            ).stdout.strip()

            ip = nm(
                "-g", "IP4.ADDRESS",
                "device", "show", WIFI,
                timeout=10
            ).stdout.strip()

            if active_uuid == uid and ip:
                logging.info(
                    "Connessione riuscita! IPv4: %s", ip
                )
                success = True
                break

            logging.info("Attesa assegnazione IPv4...")
            time.sleep(1)

    if success:
        # Salva la rete per i successivi avvii.
        saved = nm(
            "connection", "modify", "uuid", uid,
            "connection.autoconnect", "yes",
            "connection.autoconnect-priority", "50",
            timeout=15
        )

        if saved.returncode != 0:
            logging.warning(
                "Autoconnect non salvato: %s",
                saved.stderr.strip()
            )

        logging.info("Provisioning Wi-Fi completato")
        return True, ""

    logging.error(
        "Connessione fallita: code=%s, errore=%s",
        r.returncode,
        r.stderr.strip() or "IPv4 non assegnato"
    )

    # Elimina il profilo solo dopo il fallimento reale
    # o l'esaurimento del tempo di verifica.
    nm(
        "connection", "delete", "uuid", uid,
        timeout=15
    )

    return False, (
        "Impossibile completare la connessione Wi-Fi. "
        "Verifica la password o la configurazione IP."
    )


STYLE = """
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* {box-sizing:border-box}
body {background:#f4f6f8;font-family:system-ui,sans-serif;
margin:0;padding:24px 12px;color:#17212d}
main {background:white;max-width:440px;margin:auto;
padding:26px;border-radius:16px;box-shadow:0 5px 24px #0001}
h1 {font-size:24px;margin-top:0}
p {color:#536172;line-height:1.5}
label {display:block;margin:17px 0 8px}
select,input[type=password] {
width:100%;padding:13px;font-size:16px;
background:white;color:#17212d;
border:1px solid #ccd2d8;border-radius:9px;
}
button {width:100%;margin-top:24px;padding:14px;
background:#1768d2;color:white;
border:0;border-radius:9px;
font-size:16px;font-weight:600}
small {color:#687686}
</style>
"""


def page(body):
    return (
        "<!doctype html><html lang='it'><head>"
        "<meta charset='utf-8'><title>Wi-Fi Kiosk</title>"
        + STYLE +
        "</head><body><main>" +
        body +
        "</main></body></html>"
    )


class Portal(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def allowed(self):
        host = self.headers.get("Host", "").split(":", 1)[0].lower()

        try:
            client = ipaddress.ip_address(self.client_address[0])
        except ValueError:
            return False

        return (
            host in (PORTAL_HOST, AP_IP)
            and client in ipaddress.ip_network("192.168.4.0/24")
        )

    def reply(self, status, body):
        data = page(body).encode("utf-8")

        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; style-src 'unsafe-inline'; "
            "form-action 'self'; base-uri 'none'; frame-ancestors 'none'"
        )
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self.allowed():
            return self.reply(403, "<h1>Accesso negato</h1>")

        if self.path != "/":
            return self.reply(404, "<h1>Pagina non trovata</h1>")

        token = secrets.token_urlsafe(32)
        now = time.monotonic()

        with token_lock:
            for old, (_, expiry) in list(tokens.items()):
                if expiry < now:
                    del tokens[old]

            tokens[token] = (self.client_address[0], now + 900)

        names = saved_networks()

        options = "".join(
            '<option value="' + html.escape(n, quote=True) + '">' +
            html.escape(n) + '</option>'
            for n in names
        )

        if not names:
            options = (
                '<option disabled value="">'
                'Nessuna rete rilevata</option>'
            )

        self.reply(200, f"""
          <h1>Configurazione Wi-Fi</h1>
          <p>Seleziona la rete a cui collegare il Raspberry.</p>

          <form action="/connect" method="post">
            <input type="hidden" name="csrf" value="{token}">

            <label>Reti disponibili</label>
            <select name="ssid" required>
              <option value="" selected disabled>
                Seleziona una rete Wi-Fi
              </option>
              {options}
            </select>

            <label>Password Wi-Fi</label>
            <input type="password" name="password"
                   minlength="8" maxlength="64" required>

            <button type="submit">Connetti</button>
          </form>

          <p><small>
            Se la connessione non riesce, l'hotspot
            tornerà disponibile e potrai riprovare.
          </small></p>
        """)

    def do_POST(self):
        if not self.allowed():
            return self.reply(403, "<h1>Accesso negato</h1>")

        if self.path != "/connect":
            return self.reply(404, "<h1>Pagina non trovata</h1>")

        try:
            length = int(self.headers.get("Content-Length", "0"))

            if not 1 <= length <= 4096:
                raise ValueError()

            form = parse_qs(
                self.rfile.read(length).decode("utf-8"),
                max_num_fields=8
            )
        except (ValueError, UnicodeDecodeError):
            return self.reply(400, "<h1>Richiesta non valida</h1>")

        def field(name):
            return form.get(name, [""])[0]

        token = field("csrf")

        with token_lock:
            entry = tokens.pop(token, None)

        if (
            not entry
            or entry[0] != self.client_address[0]
            or entry[1] < time.monotonic()
        ):
            return self.reply(
                403, "<h1>Ricarica la pagina e riprova</h1>"
            )

        ssid = field("ssid")
        password = field("password")

        if ssid not in saved_networks():
            return self.reply(
                400, "<h1>Seleziona una rete valida</h1>"
            )

        valid_password = (
            8 <= len(password) <= 63
            or (
                len(password) == 64
                and all(
                    c in "0123456789abcdefABCDEF"
                    for c in password
                )
            )
        )

        if not valid_password or any(ord(c) < 32 for c in password):
            return self.reply(
                400, "<h1>Password non valida</h1>"
            )

        try:
            jobs.put_nowait((ssid, password))
        except queue.Full:
            return self.reply(
                409, "<h1>Connessione già in corso</h1>"
            )

        self.reply(200, """
          <h1>Connessione in corso</h1>
          <p>Il Raspberry sta verificando la rete selezionata.</p>
          <p>L'hotspot verrà temporaneamente disattivato.</p>
          <p>Se la connessione riesce, il monitor mostrerà
          la dashboard.</p>
          <p>Altrimenti l'hotspot tornerà disponibile:
          ricollegati e riapri <b>http://kiosk.lan</b>.</p>
        """)


def serve_portal():
    server = ThreadingHTTPServer((AP_IP, 80), Portal)
    server.daemon_threads = True
    server.timeout = 2

    logging.info("Portale disponibile: http://%s", PORTAL_HOST)

    try:
        while ap_active() and not ethernet_online():
            server.handle_request()

            try:
                return jobs.get_nowait()
            except queue.Empty:
                continue

        return None
    finally:
        server.server_close()


def main():
    previous_mode = None
    disconnected_since = None
    error_message = ""

    while True:
        wired = ethernet_online()

        # Se Ethernet è disponibile, non serve l'hotspot.
        if wired and ap_active():
            logging.info(
                "Ethernet con Internet rilevata: disattivo hotspot"
            )

            r = nm(
                "connection", "down", "id", AP,
                timeout=20
            )

            if r.returncode != 0:
                logging.warning(
                    "Disattivazione hotspot non riuscita: %s",
                    r.stderr.strip()
                )

        online = wired or wifi_online()

        mode = "app" if online else "setup"

        if mode != previous_mode:
            logging.info("Modalità: %s", mode)

            if not online:
                render_offline(error_message)

            restart_kiosk()
            previous_mode = mode

        if online:
            disconnected_since = None
            error_message = ""
            time.sleep(5)
            continue

        if not ap_active():
            if disconnected_since is None:
                disconnected_since = time.monotonic()

            if time.monotonic() - disconnected_since < WAIT_FOR_WIFI:
                time.sleep(5)
                continue

            scan_networks()

            if not start_ap():
                time.sleep(10)
                continue

        try:
            job = serve_portal()
        except OSError as exc:
            logging.error("Portale: %s", exc)
            time.sleep(5)
            continue

        if job is None:
            time.sleep(2)
            continue

        ssid, password = job

        # Lascia completare la risposta HTTP al telefono.
        time.sleep(3)

        render_offline("Connessione alla rete in corso...")
        restart_kiosk()

        success, error = connect_new_wifi(ssid, password)

        if success:
            disconnected_since = None
            error_message = ""
            continue

        error_message = error
        render_offline(error_message)
        restart_kiosk()

        disconnected_since = time.monotonic() - WAIT_FOR_WIFI

        if not wifi_online():
            scan_networks()
            start_ap()


if __name__ == "__main__":
    main()
